// dashboard.js — fills dashboard.html with data. The HTML has empty containers; JavaScript
// reads the data, builds HTML strings with map()/join(), and inserts them into the page.

const RECENT_COUNT = 5;

const renderStats = (user) => {
  const { balance, totalEarned, transactionCount } = getWalletStats(user.id);
  const isMining = getActiveSession(user.id) !== null;

  const cards = [
    { label: t("stat.balance"), value: formatAmount(balance), icon: "fa-coins" },
    { label: t("stat.miningStatus"), value: t(isMining ? "status.active" : "status.inactive"), icon: "fa-hammer" },
    { label: t("stat.totalEarned"), value: formatAmount(totalEarned), icon: "fa-arrow-trend-up" },
    { label: t("stat.transactions"), value: transactionCount, icon: "fa-list" },
  ];
  document.getElementById("stats").innerHTML = cards.map(renderStatCard).join("");
};

const renderRecentTransactions = (user) => {
  const recent = getUserTransactions(user.id).slice(0, RECENT_COUNT);
  document.getElementById("recent-transactions").innerHTML =
    recent.length > 0 ? recent.map(renderTransactionItem).join("") : renderEmptyState("transactions.empty");
};

const renderMiningSummary = (user) => {
  const session = getActiveSession(user.id);
  const container = document.getElementById("mining-summary");

  if (!session) {
    container.innerHTML = `
      <p class="font-semibold">${t("mining.notMining")}</p>
      <p class="mt-1 text-sm text-slate-500">${t("mining.notMiningHint")}</p>`;
    return;
  }
  container.innerHTML = `
    <p class="text-sm text-slate-500">${t("mining.earning")}</p>
    <p class="text-2xl font-bold text-blue-600">${formatAmount(calculateEarning(session), 4)}</p>
    <p class="mt-3 text-sm text-slate-500">${t("mining.timeLeft")}</p>
    <p class="font-mono text-xl tabular-nums">${formatDuration(getRemainingMs(session))}</p>`;
};

const initDashboardPage = (user) => {
  document.getElementById("welcome-name").textContent = user.fullName;
  document.getElementById("welcome-subtitle").textContent = `${user.email} \u2022 ${user.walletAddress}`;

  renderStats(user);
  renderRecentTransactions(user);
  renderMiningSummary(user);

  // Every second: finish ended sessions, then redraw the mining card from Date.now()
  setInterval(() => {
    const completed = completeExpiredSessions(user.id);
    if (completed.length > 0) {
      announceCompleted(completed);
      renderStats(user);
      renderRecentTransactions(user);
    }
    renderMiningSummary(user);
  }, 1000);
};
