// utils.js — small helpers shared by every module (no DOM, no storage).

// Unique id such as "tx_lq3k9a1b2c" built from the current time + a random part
const generateId = (prefix) =>
  `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

// Fictional wallet identifier such as "PAS-3F9A1C7D2B4E6A80"
const generateWalletAddress = () => {
  const hex = Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16));
  return `PAS-${hex.join("").toUpperCase()}`;
};

// Round to avoid floating point noise (0.1 + 0.2 = 0.30000000000000004)
const roundTo = (value, decimals = 4) => {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
};

const formatAmount = (amount, decimals = 2) => `${Number(amount).toFixed(decimals)} PAS`;

const formatDate = (timestamp, locale) =>
  new Date(timestamp).toLocaleString(locale, { dateStyle: "medium", timeStyle: "short" });

// 3 725 000 ms  ->  "01:02:05"
const formatDuration = (milliseconds) => {
  const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds].map((n) => String(n).padStart(2, "0")).join(":");
};

// Prevents user text (e.g. a name like "<b>Hi</b>") from becoming real HTML
// when we build markup with template literals and innerHTML.
const escapeHtml = (text) =>
  String(text).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[char]));

// Emails are compared in lower case without spaces, so ADA@Mail.com equals ada@mail.com
const normalizeEmail = (email) => String(email).trim().toLowerCase();

// ----- Field validators (return true / false) -----
const isNotEmpty = (value) => typeof value === "string" && value.trim() !== "";
const isValidEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(value).trim());
const isValidPhone = (value) => /^\+?[0-9\s-]{7,15}$/.test(String(value).trim());
const isValidPassword = (value) => typeof value === "string" && value.length >= 6;
