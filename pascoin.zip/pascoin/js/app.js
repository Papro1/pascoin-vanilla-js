// app.js — entry point, loaded LAST by every page (after all the other scripts).
// The scripts share one global scope, so each file can call the functions defined in the files before it.
// Order matters: prepare data -> find the user -> protect the page -> build the interface.

// Each page name maps to the function that makes that page work
const pageInitializers = {
  login: initLoginPage,
  register: initRegisterPage,
  dashboard: initDashboardPage,
  mining: initMiningPage,
  wallet: initWalletPage,
  profile: initProfilePage,
  about: initAboutPage,
  transactions: initTransactionsPage,
};

const startApp = () => {
  document.body.dataset.started = "true"; // tells the safety net in each HTML page that the app is running
  if (initializeStorage()) seedDemoData(); // first launch only
  applySettings(); // theme + language, before anything is shown

  const user = getCurrentUser();
  if (!protectPage(user)) return; // redirecting, stop here

  document.body.dataset.ready = "true"; // reveals protected pages (see styles.css)
  setupNavbar(user, logoutUser);
  setupSettingsControls();

  // Sessions that ended while the browser was closed are paid now
  if (user) announceCompleted(completeExpiredSessions(user.id));

  pageInitializers[document.body.dataset.page]?.(user);
};

startApp();
