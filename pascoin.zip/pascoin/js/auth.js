// auth.js — registration, login, logout, current user and page protection.
// How it works: a "session" is just the logged-in user's id saved in LocalStorage.
// SECURITY NOTE: plain-text passwords + LocalStorage are NOT real authentication (see storage.js).

const SIGNUP_BONUS = 10;

// ---------- Current user ----------
const getCurrentUser = () => {
  const userId = getCurrentUserId();
  if (!userId) return null;
  const user = findById("users", userId);
  if (!user) clearCurrentUser(); // session points to a user that no longer exists
  return user;
};

// ---------- Validation: returns { fieldId: messageKey } (empty object = valid) ----------
const validateRegistration = ({ fullName, phone, email, password, confirmPassword }) => {
  const errors = {};

  if (!isNotEmpty(fullName)) errors.fullName = "error.required";

  if (!isNotEmpty(phone)) errors.phone = "error.required";
  else if (!isValidPhone(phone)) errors.phone = "error.phoneInvalid";

  if (!isNotEmpty(email)) errors.email = "error.required";
  else if (!isValidEmail(email)) errors.email = "error.emailInvalid";
  else if (getAll("users").some((user) => user.email === normalizeEmail(email))) errors.email = "error.emailTaken";

  if (!isNotEmpty(password)) errors.password = "error.required";
  else if (!isValidPassword(password)) errors.password = "error.passwordShort";

  if (!isNotEmpty(confirmPassword)) errors.confirmPassword = "error.required";
  else if (confirmPassword !== password) errors.confirmPassword = "error.passwordMismatch";

  return errors;
};

// ---------- Register ----------
const registerUser = (formData) => {
  const errors = validateRegistration(formData);
  if (Object.keys(errors).length > 0) return { ok: false, errors };

  const { fullName, phone, email, password } = formData;
  const newUser = {
    id: generateId("user"),
    fullName: fullName.trim(),
    phone: phone.trim(),
    email: normalizeEmail(email),
    password,
    walletAddress: generateWalletAddress(),
    photo: null,
    createdAt: Date.now(),
  };

  if (!insert("users", newUser)) return { ok: false, formError: "error.saveFailed" };

  // The initial balance is a transaction, so balance = sum of transactions
  createTransaction({
    userId: newUser.id, type: "reward", amount: SIGNUP_BONUS, description: "Welcome bonus",
  });
  return { ok: true, user: newUser };
};

// ---------- Login / logout ----------
const loginUser = ({ email, password }) => {
  const errors = {};
  if (!isNotEmpty(email)) errors.email = "error.required";
  if (!isNotEmpty(password)) errors.password = "error.required";
  if (Object.keys(errors).length > 0) return { ok: false, errors };

  const user = getAll("users").find((u) => u.email === normalizeEmail(email) && u.password === password);
  // One generic message: we do not reveal whether the email or the password was wrong
  if (!user) return { ok: false, formError: "error.invalidCredentials" };

  setCurrentUserId(user.id);
  return { ok: true, user };
};

const logoutUser = () => {
  clearCurrentUser();
  window.location.href = "login.html";
};

// ---------- Page protection ----------
// Returns true if the page may be displayed. Otherwise redirects and returns false.
const protectPage = (user) => {
  const page = document.body.dataset.page;
  const isProtected = document.body.dataset.protected === "true";
  const isGuestPage = ["login", "register"].includes(page);

  if (isProtected && !user) {
    window.location.replace("login.html");
    return false;
  }
  if (isGuestPage && user) {
    window.location.replace("dashboard.html");
    return false;
  }
  return true;
};

// ---------- Form wiring ----------
const initRegisterPage = () => {
  const form = document.getElementById("register-form");
  setupForm(form, (formData) => {
    const result = registerUser(formData);
    if (!result.ok) return showFormErrors(form, result);
    window.location.href = "login.html?registered=1";
  });
};

const initLoginPage = () => {
  const form = document.getElementById("login-form");
  if (new URLSearchParams(window.location.search).get("registered") === "1") {
    showToast(t("toast.registered"));
  }
  setupForm(form, (formData) => {
    const result = loginUser(formData);
    if (!result.ok) return showFormErrors(form, result);
    window.location.href = "dashboard.html";
  });
};
