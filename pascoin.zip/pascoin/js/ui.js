// ui.js — reusable interface helpers: form errors, toasts, confirmation dialog, navbar behaviour.

// ---------- Form errors ----------
const showFieldError = (fieldId, messageKey) => {
  const errorElement = document.getElementById(`${fieldId}-error`);
  const input = document.getElementById(fieldId);
  if (!errorElement) return;
  errorElement.textContent = t(messageKey);
  errorElement.classList.remove("hidden");
  input?.setAttribute("aria-invalid", "true");
};

const clearFieldError = (fieldId) => {
  const errorElement = document.getElementById(`${fieldId}-error`);
  errorElement?.classList.add("hidden");
  document.getElementById(fieldId)?.removeAttribute("aria-invalid");
};

const clearFormErrors = (form) => {
  form.querySelectorAll('[role="alert"]').forEach((element) => element.classList.add("hidden"));
  form.querySelectorAll("[aria-invalid]").forEach((input) => input.removeAttribute("aria-invalid"));
};

// result = { errors: { fieldId: messageKey }, formError: messageKey }
const showFormErrors = (form, { errors = {}, formError }) => {
  Object.entries(errors).forEach(([fieldId, messageKey]) => showFieldError(fieldId, messageKey));
  const formErrorElement = form.querySelector("#form-error");
  if (formError && formErrorElement) {
    formErrorElement.textContent = t(formError);
    formErrorElement.classList.remove("hidden");
  }
  form.querySelector('[aria-invalid="true"]')?.focus();
};

// Wires a form: clears a field's error when edited, and on submit gives handleSubmit the form data
const setupForm = (form, handleSubmit) => {
  // Remove a field's error as soon as the user edits it
  form.addEventListener("input", (event) => clearFieldError(event.target.id));
  form.addEventListener("submit", (event) => {
    event.preventDefault(); // stop the browser from reloading the page
    clearFormErrors(form);
    handleSubmit(Object.fromEntries(new FormData(form))); // { fieldName: value, ... }
  });
};

// ---------- Toast notification ----------
const showToast = (message, type = "success") => {
  const container = document.getElementById("toast-container");
  if (!container) return;
  const toast = document.createElement("div");
  const color = type === "error" ? "bg-red-600" : "bg-green-600";
  toast.className = `rounded-lg px-4 py-3 text-sm font-medium text-white shadow-lg ${color}`;
  toast.setAttribute("role", "status");
  toast.textContent = message; // textContent (not innerHTML) keeps it safe
  container.append(toast);
  setTimeout(() => toast.remove(), 3500);
};

// ---------- Confirmation dialog (resolves to true or false) ----------
const confirmDialog = (title, message) =>
  new Promise((resolve) => {
    const dialog = document.getElementById("confirm-dialog");
    document.getElementById("confirm-title").textContent = title;
    document.getElementById("confirm-message").textContent = message;

    const finish = (answer) => {
      dialog.close();
      resolve(answer);
    };
    document.getElementById("confirm-ok").onclick = () => finish(true);
    document.getElementById("confirm-cancel").onclick = () => finish(false);
    dialog.oncancel = () => finish(false); // Escape key
    dialog.showModal();
  });

// ---------- Navbar: show the right links, highlight the page, menu button, logout ----------
const setupNavbar = (user, onLogout) => {
  const state = user ? "user" : "guest";

  document.querySelectorAll("[data-auth]").forEach((item) => {
    const visible = item.dataset.auth === "all" || item.dataset.auth === state;
    item.classList.toggle("hidden", !visible);
  });

  const currentFile = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll("[data-nav]").forEach((link) => {
    link.classList.toggle("is-active", link.dataset.nav === currentFile);
  });

  const menuButton = document.getElementById("menu-toggle");
  const mobileMenu = document.getElementById("mobile-menu");
  const setMenuOpen = (isOpen) => {
    mobileMenu?.classList.toggle("hidden", !isOpen);
    menuButton?.setAttribute("aria-expanded", String(isOpen));
  };
  menuButton?.addEventListener("click", () => setMenuOpen(mobileMenu.classList.contains("hidden")));
  document.addEventListener("keydown", (event) => event.key === "Escape" && setMenuOpen(false));
  // When the window grows to desktop width (1024px) the menu is replaced by the top links
  window.matchMedia?.("(min-width: 1024px)").addEventListener("change", (event) => event.matches && setMenuOpen(false));

  document.querySelectorAll('[data-action="logout"]').forEach((button) => {
    button.addEventListener("click", async () => {
      const confirmed = await confirmDialog(t("dialog.logoutTitle"), t("dialog.logoutMessage"));
      if (confirmed) onLogout();
    });
  });
};

// ---------- Rendering helpers: functions that return HTML strings ----------
const CARD_CLASSES = "rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800";

const renderStatCard = ({ label, value, icon }) => `
  <article class="${CARD_CLASSES}">
    <div class="flex items-center justify-between">
      <h3 class="text-sm font-medium text-slate-500 dark:text-slate-400">${label}</h3>
      <i class="fa-solid ${icon} text-blue-600" aria-hidden="true"></i>
    </div>
    <p class="mt-2 text-2xl font-bold">${value}</p>
  </article>`;

const renderEmptyState = (messageKey) =>
  `<li class="py-6 text-center text-sm text-slate-500">${t(messageKey)}</li>`;

// Descriptions are saved in English; the known ones are shown in the current language
const DESCRIPTION_KEYS = {
  "Welcome bonus": "desc.welcomeBonus",
  "24-hour mining session": "desc.miningSession",
};
const describe = (description) => (DESCRIPTION_KEYS[description] ? t(DESCRIPTION_KEYS[description]) : description);

// One row of a transaction list (used by dashboard, wallet and transactions pages)
const renderTransactionItem = (transaction) => {
  const { type, amount, date, status, description } = transaction;
  const isCredit = amount >= 0;
  const amountColor = isCredit ? "text-green-600" : "text-red-600";
  const sign = isCredit ? "+" : "";
  return `
  <li class="flex items-center justify-between gap-3 py-3">
    <div class="min-w-0">
      <p class="font-medium">${t(`type.${type}`)}</p>
      <p class="truncate text-sm text-slate-500 dark:text-slate-400">${escapeHtml(describe(description))} &middot; ${formatDate(date, getLocale())}</p>
    </div>
    <div class="shrink-0 text-right">
      <p class="font-semibold ${amountColor}">${sign}${formatAmount(amount)}</p>
      <p class="text-xs text-slate-500">${t(`status.${status}`)}</p>
    </div>
  </li>`;
};
