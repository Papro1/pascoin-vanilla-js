// transactions.js — creating, reading and filtering transactions, and the transactions page.

// type: "mining" | "reward" | "other"
const createTransaction = ({ userId, type, amount, description, status = "completed" }) =>
  insert("transactions", {
    id: generateId("tx"),
    userId,
    type,
    amount,
    date: Date.now(),
    status,
    description,
  });

// All transactions of one user, newest first
const getUserTransactions = (userId) =>
  getAll("transactions")
    .filter((transaction) => transaction.userId === userId)
    .sort((a, b) => b.date - a.date);

// Each filter name maps to a function that says whether a transaction is kept
const FILTERS = {
  all: () => true,
  mining: (tx) => tx.type === "mining",
  reward: (tx) => tx.type === "reward",
  other: (tx) => tx.type === "other",
};

const filterTransactions = (transactions, filterName) =>
  transactions.filter(FILTERS[filterName] ?? FILTERS.all);

// ---------- Transactions page ----------
const BUTTON_BASE = "inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/50";
const BUTTON_ON = "bg-blue-600 text-white hover:bg-blue-700";
const BUTTON_OFF = "border border-slate-300 hover:bg-slate-100 dark:border-slate-600 dark:hover:bg-slate-700";

const initTransactionsPage = (user) => {
  const list = document.getElementById("transaction-list");
  const emptyState = document.getElementById("empty-state");
  const filterButtons = document.querySelectorAll("#filters [data-filter]");
  const allTransactions = getUserTransactions(user.id);

  const render = (filterName) => {
    const visible = filterTransactions(allTransactions, filterName);
    list.innerHTML = visible.map(renderTransactionItem).join("");

    emptyState.textContent = t(filterName === "all" ? "transactions.empty" : "transactions.emptyFiltered");
    emptyState.classList.toggle("hidden", visible.length > 0);

    filterButtons.forEach((button) => {
      const isSelected = button.dataset.filter === filterName;
      button.className = `${BUTTON_BASE} ${isSelected ? BUTTON_ON : BUTTON_OFF}`;
      button.setAttribute("aria-pressed", String(isSelected));
    });
  };

  // One listener on the container handles all four buttons (event delegation)
  document.getElementById("filters").addEventListener("click", (event) => {
    const button = event.target.closest("[data-filter]");
    if (button) render(button.dataset.filter);
  });

  render("all");
};
