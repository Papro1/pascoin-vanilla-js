// storage.js — the ONLY file that touches localStorage. It plays the role of a small database.
// Other modules call getAll / insert / updateById / removeById and never use localStorage directly.
//
// SECURITY NOTE: LocalStorage is readable by anyone using this browser, and passwords are stored
// as plain text here. That is NOT secure and must never be done in a real application.
// It is acceptable only because this university project simulates a backend in the browser.

const KEYS = {
  users: "pascoin_users",
  currentUser: "pascoin_current_user",
  transactions: "pascoin_transactions",
  miningSessions: "pascoin_mining_sessions",
  settings: "pascoin_settings",
  initialized: "pascoin_initialized",
};

const DEFAULT_SETTINGS = { theme: "light", language: "en" };
const THEMES = ["light", "dark"];
const LANGUAGES = ["en", "fr", "sw"];

// ---------- Validators: decide whether a stored object is usable ----------
const isObject = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
const isText = (value) => typeof value === "string" && value !== "";

const isValidUser = (u) =>
  isObject(u) && [u.id, u.fullName, u.email, u.password, u.walletAddress].every(isText) &&
  typeof u.phone === "string" && Number.isFinite(u.createdAt);

const isValidTransaction = (t) =>
  isObject(t) && isText(t.id) && isText(t.userId) &&
  ["mining", "reward", "other"].includes(t.type) &&
  Number.isFinite(t.amount) && Number.isFinite(t.date) &&
  isText(t.status) && typeof t.description === "string";

const isValidSession = (s) =>
  isObject(s) && isText(s.id) && isText(s.userId) &&
  Number.isFinite(s.startTime) && Number.isFinite(s.endTime) &&
  ["active", "completed"].includes(s.status);

const VALIDATORS = {
  users: isValidUser,
  transactions: isValidTransaction,
  miningSessions: isValidSession,
};

// ---------- Low-level read / write (JSON + error handling) ----------
const readData = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch (error) {
    console.warn(`Pascoin: "${key}" is corrupted, using default value.`, error);
    return fallback;
  }
};

// Returns false instead of crashing when storage is full or blocked
const writeData = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    console.error(`Pascoin: could not save "${key}" (storage full or blocked).`, error);
    return false;
  }
};

// ---------- Collections: users, transactions, miningSessions ----------
// Reading also repairs the data: invalid entries are dropped and the clean array is saved back.
const getAll = (collection) => {
  const key = KEYS[collection];
  const data = readData(key, []);
  if (!Array.isArray(data)) {
    writeData(key, []);
    return [];
  }
  const validItems = data.filter(VALIDATORS[collection]);
  if (validItems.length !== data.length) writeData(key, validItems);
  return validItems;
};

const findById = (collection, id) => getAll(collection).find((item) => item.id === id) ?? null;

const insert = (collection, item) => {
  if (!VALIDATORS[collection](item)) {
    console.error(`Pascoin: refused to insert invalid item in "${collection}".`, item);
    return null;
  }
  const saved = writeData(KEYS[collection], [...getAll(collection), item]);
  return saved ? item : null;
};

// Merges `changes` into the item with this id. Returns the updated item, or null.
const updateById = (collection, id, changes) => {
  let updatedItem = null;
  const items = getAll(collection).map((item) => {
    if (item.id !== id) return item;
    updatedItem = { ...item, ...changes };
    return updatedItem;
  });
  if (!updatedItem || !VALIDATORS[collection](updatedItem)) return null;
  return writeData(KEYS[collection], items) ? updatedItem : null;
};

const removeById = (collection, id) => {
  const items = getAll(collection);
  const remaining = items.filter((item) => item.id !== id);
  if (remaining.length === items.length) return false;
  return writeData(KEYS[collection], remaining);
};

// ---------- Session: who is logged in (stores only the user id, as plain text) ----------
const getCurrentUserId = () => localStorage.getItem(KEYS.currentUser);
const setCurrentUserId = (userId) => localStorage.setItem(KEYS.currentUser, userId);
const clearCurrentUser = () => localStorage.removeItem(KEYS.currentUser);

// ---------- Settings: theme + language ----------
const getSettings = () => {
  const stored = readData(KEYS.settings, {});
  const theme = THEMES.includes(stored.theme) ? stored.theme : DEFAULT_SETTINGS.theme;
  const language = LANGUAGES.includes(stored.language) ? stored.language : DEFAULT_SETTINGS.language;
  return { theme, language };
};

const saveSettings = (changes) => {
  const settings = { ...getSettings(), ...changes };
  writeData(KEYS.settings, settings);
  return getSettings();
};

// ---------- First launch ----------
// Returns true only the very first time, so the caller can add demo data.
const initializeStorage = () => {
  if (localStorage.getItem(KEYS.initialized)) return false;
  writeData(KEYS.users, []);
  writeData(KEYS.transactions, []);
  writeData(KEYS.miningSessions, []);
  writeData(KEYS.settings, DEFAULT_SETTINGS);
  localStorage.setItem(KEYS.initialized, "true");
  return true;
};

// Demo account, flagged isDemo so it is clearly separate from real registrations.
const seedDemoData = () => {
  const demoUser = {
    id: "user_demo",
    fullName: "Demo User",
    phone: "+243 000 000 000",
    email: "demo@pascoin.test",
    password: "demo1234",
    walletAddress: generateWalletAddress(),
    photo: null,
    createdAt: Date.now(),
    isDemo: true,
  };
  insert("users", demoUser);
  insert("transactions", {
    id: generateId("tx"), userId: demoUser.id, type: "reward", amount: 10,
    date: Date.now(), status: "completed", description: "Welcome bonus",
  });
};

// Developer helper: wipes every Pascoin key (useful while testing)
const resetAllData = () => Object.values(KEYS).forEach((key) => localStorage.removeItem(key));
