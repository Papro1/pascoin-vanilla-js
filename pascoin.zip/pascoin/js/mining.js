// mining.js — the mining system: rules, sessions, rewards and the mining page.
//
// How it works:
//  * Starting a session saves startTime and endTime (timestamps in milliseconds).
//  * The earning is NEVER stored while mining. It is calculated from Date.now() each time it is
//    needed: earning = hours elapsed x 1 PAS (maximum 24). So closing the browser changes nothing.
//  * When Date.now() >= endTime the session is completed: it is marked "completed" and one
//    "mining" transaction is created. This check runs on every page load (see app.js) and
//    every second on the dashboard and mining pages.

const MINING_RATE_PER_HOUR = 1;
const SESSION_DURATION_MS = 24 * 60 * 60 * 1000;
const MAX_REWARD = 24;
const HOUR_MS = 60 * 60 * 1000;

// ---------- Reading and calculating ----------
const getActiveSession = (userId) =>
  getAll("miningSessions").find((s) => s.userId === userId && s.status === "active") ?? null;

const getSessionHistory = (userId) =>
  getAll("miningSessions")
    .filter((s) => s.userId === userId)
    .sort((a, b) => b.startTime - a.startTime);

// Calculate mining reward based on elapsed time (never more than 24 hours counts)
const calculateEarning = (session, now = Date.now()) => {
  const elapsed = Math.min(Math.max(now - session.startTime, 0), SESSION_DURATION_MS);
  return roundTo((elapsed / HOUR_MS) * MINING_RATE_PER_HOUR, 4);
};

const getRemainingMs = (session, now = Date.now()) => Math.max(0, session.endTime - now);

// ---------- Starting a session ----------
const startMining = (userId) => {
  // The real protection against two sessions lives here, not only in the disabled button
  if (getActiveSession(userId)) return { ok: false, error: "error.alreadyMining" };

  const now = Date.now();
  const session = {
    id: generateId("mine"),
    userId,
    startTime: now,
    endTime: now + SESSION_DURATION_MS,
    status: "active",
  };
  return insert("miningSessions", session)
    ? { ok: true, session }
    : { ok: false, error: "error.saveFailed" };
};

// ---------- Completing sessions ----------
// Marks the session completed FIRST, then pays. This way a session can never be paid twice.
const completeSession = (session) => {
  // Re-read the stored session: another browser tab may have paid it a moment ago
  const stored = findById("miningSessions", session.id);
  if (!stored || stored.status !== "active") return null;

  const reward = Math.min(calculateEarning(session, session.endTime), MAX_REWARD);
  if (!updateById("miningSessions", session.id, { status: "completed" })) return null;

  const transaction = createTransaction({
    userId: session.userId,
    type: "mining",
    amount: reward,
    description: "24-hour mining session",
  });
  if (!transaction) {
    updateById("miningSessions", session.id, { status: "active" }); // payment failed: retry later
    return null;
  }
  return { session, reward };
};

// Completes every finished session of this user. Returns [{ session, reward }, ...]
const completeExpiredSessions = (userId, now = Date.now()) =>
  getAll("miningSessions")
    .filter((s) => s.userId === userId && s.status === "active" && now >= s.endTime)
    .map(completeSession)
    .filter((result) => result !== null);

const announceCompleted = (results) => {
  if (results.length === 0) return;
  const totalReward = results.reduce((sum, result) => sum + result.reward, 0);
  showToast(`${t("toast.miningCompleted")} +${formatAmount(totalReward)}`);
};

// ---------- Mining page ----------
const BADGE_BASE = "rounded-full px-3 py-1 text-sm font-medium";
const BADGE_ACTIVE = "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200";
const BADGE_INACTIVE = "bg-slate-200 dark:bg-slate-700";

const renderSessionItem = (session) => {
  const isActive = session.status === "active";
  const reward = isActive ? calculateEarning(session) : calculateEarning(session, session.endTime);
  const locale = getLocale();
  return `
  <li class="flex items-center justify-between gap-3 py-3">
    <div>
      <p class="font-medium">${formatDate(session.startTime, locale)}</p>
      <p class="text-sm text-slate-500 dark:text-slate-400">${t("mining.sessionEnds")} ${formatDate(session.endTime, locale)}</p>
    </div>
    <div class="text-right">
      <p class="font-semibold">${formatAmount(reward, isActive ? 4 : 2)}</p>
      <p class="text-xs text-slate-500">${t(`status.${session.status}`)}</p>
    </div>
  </li>`;
};

const renderMiningPage = (user) => {
  const session = getActiveSession(user.id);
  const earning = session ? calculateEarning(session) : 0;
  const remaining = session ? getRemainingMs(session) : 0;
  const percent = (earning / MAX_REWARD) * 100;

  document.getElementById("countdown").textContent = formatDuration(remaining);
  document.getElementById("current-earning").textContent = formatAmount(earning, 4);
  document.getElementById("progress-text").textContent = `${percent.toFixed(1)}%`;

  const bar = document.getElementById("progress-bar");
  bar.style.width = `${percent}%`;
  bar.setAttribute("aria-valuenow", Math.round(percent));

  const badge = document.getElementById("mining-status");
  badge.textContent = t(session ? "status.active" : "status.inactive");
  badge.className = `${BADGE_BASE} ${session ? BADGE_ACTIVE : BADGE_INACTIVE}`;

  const startButton = document.getElementById("start-mining");
  startButton.disabled = session !== null;
  startButton.textContent = t(session ? "mining.inProgress" : "mining.start");

  const history = getSessionHistory(user.id);
  document.getElementById("session-history").innerHTML =
    history.length > 0 ? history.map(renderSessionItem).join("") : renderEmptyState("mining.noHistory");
};

const initMiningPage = (user) => {
  document.getElementById("start-mining").addEventListener("click", () => {
    const result = startMining(user.id);
    if (!result.ok) return showToast(t(result.error), "error");
    showToast(t("toast.miningStarted"));
    renderMiningPage(user);
  });

  renderMiningPage(user);

  // Every second: finish the session if its time is up, then redraw from Date.now()
  setInterval(() => {
    announceCompleted(completeExpiredSessions(user.id));
    renderMiningPage(user);
  }, 1000);
};
