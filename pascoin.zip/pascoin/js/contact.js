// contact.js — the About page: working contact form (simulated, nothing is sent or stored).

const validateContact = ({ contactName, contactEmail, contactMessage }) => {
  const errors = {};
  if (!isNotEmpty(contactName)) errors.contactName = "error.required";

  if (!isNotEmpty(contactEmail)) errors.contactEmail = "error.required";
  else if (!isValidEmail(contactEmail)) errors.contactEmail = "error.emailInvalid";

  if (!isNotEmpty(contactMessage)) errors.contactMessage = "error.required";
  else if (contactMessage.trim().length < 10) errors.contactMessage = "error.messageShort";
  return errors;
};

const initAboutPage = (user) => {
  const form = document.getElementById("contact-form");

  // Logged-in visitors do not need to retype their name and email
  const prefill = () => {
    if (!user) return;
    document.getElementById("contactName").value = user.fullName;
    document.getElementById("contactEmail").value = user.email;
  };
  prefill();

  setupForm(form, (formData) => {
    const errors = validateContact(formData);
    if (Object.keys(errors).length > 0) return showFormErrors(form, { errors });
    form.reset();
    prefill();
    showToast(t("toast.messageSent"));
  });
};
