// settings.js — dark mode and language. Both choices live in LocalStorage ("pascoin_settings")
// and are applied again on every page load, so they survive a refresh.

const TITLE_KEYS = {
  home: "nav.home", login: "nav.login", register: "nav.register", dashboard: "nav.dashboard",
  mining: "nav.mining", wallet: "nav.wallet", transactions: "nav.transactions",
  profile: "nav.profile", about: "nav.about",
};

// ---------- Dark mode ----------
// Tailwind uses darkMode: 'class': every dark: style is active when <html> has the class "dark".
const applyTheme = (theme) => {
  const isDark = theme === "dark";
  document.documentElement.classList.toggle("dark", isDark);

  const button = document.getElementById("theme-toggle");
  button?.setAttribute("aria-pressed", String(isDark));
  const icon = button?.querySelector("i");
  icon?.classList.toggle("fa-sun", isDark);   // show the icon of the mode you can switch to
  icon?.classList.toggle("fa-moon", !isDark);
};

// ---------- Language ----------
const applyLanguage = (language) => {
  document.documentElement.lang = language;
  applyTranslations(); // replaces every [data-i18n] text (see i18n.js)

  const titleKey = TITLE_KEYS[document.body.dataset.page];
  if (titleKey) document.title = `${t(titleKey)} | Pascoin`;

  const select = document.getElementById("language-select");
  if (select) select.value = language;
};

// Applies the saved settings. Called first on every page.
const applySettings = () => {
  const { theme, language } = getSettings();
  applyTheme(theme);
  applyLanguage(language);
};

// ---------- Controls in the navbar ----------
const setupSettingsControls = () => {
  document.getElementById("theme-toggle")?.addEventListener("click", () => {
    const newTheme = getSettings().theme === "dark" ? "light" : "dark";
    saveSettings({ theme: newTheme });
    applyTheme(newTheme);
  });

  document.getElementById("language-select")?.addEventListener("change", (event) => {
    saveSettings({ language: event.target.value });
    // Reloading redraws the texts built by JavaScript (stats, lists, messages) in the new language
    window.location.reload();
  });
};
