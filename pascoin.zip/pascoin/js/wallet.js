// wallet.js — balance, statistics and the wallet page. Nothing is stored: everything is
// calculated from the user's transactions, so the balance can never disagree with the history.

const sumAmounts = (transactions) => transactions.reduce((total, tx) => total + tx.amount, 0);

const getBalance = (userId) => {
  const completed = getUserTransactions(userId).filter((tx) => tx.status === "completed");
  return roundTo(sumAmounts(completed), 4);
};

const getWalletStats = (userId) => {
  const transactions = getUserTransactions(userId);
  const completed = transactions.filter((tx) => tx.status === "completed");
  const credits = completed.filter((tx) => tx.amount > 0);

  return {
    balance: roundTo(sumAmounts(completed), 4),
    totalEarned: roundTo(sumAmounts(credits), 4),
    miningRewards: roundTo(sumAmounts(credits.filter((tx) => tx.type === "mining")), 4),
    transactionCount: transactions.length,
  };
};

// ---------- Wallet page ----------
const copyAddress = async (address) => {
  try {
    await navigator.clipboard.writeText(address); // only works on https:// or localhost
    showToast(t("toast.addressCopied"));
  } catch (error) {
    showToast(t("error.copyFailed"), "error");
  }
};

const initWalletPage = (user) => {
  const { balance, totalEarned, miningRewards, transactionCount } = getWalletStats(user.id);

  document.getElementById("wallet-balance").textContent = formatAmount(balance);
  document.getElementById("wallet-address").textContent = user.walletAddress;

  const cards = [
    { label: t("stat.totalEarned"), value: formatAmount(totalEarned), icon: "fa-arrow-trend-up" },
    { label: t("stat.miningRewards"), value: formatAmount(miningRewards), icon: "fa-hammer" },
    { label: t("stat.transactions"), value: transactionCount, icon: "fa-list" },
  ];
  document.getElementById("wallet-stats").innerHTML = cards.map(renderStatCard).join("");

  const recent = getUserTransactions(user.id).slice(0, 5);
  document.getElementById("wallet-transactions").innerHTML =
    recent.length > 0 ? recent.map(renderTransactionItem).join("") : renderEmptyState("transactions.empty");

  document.getElementById("copy-address").addEventListener("click", () => copyAddress(user.walletAddress));
};
