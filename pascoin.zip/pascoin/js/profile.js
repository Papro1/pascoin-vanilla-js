// profile.js — view and update the profile: personal info, photo and password.

const PHOTO_SIZE = 200;                  // pixels: the photo is shrunk to 200 x 200
const MAX_PHOTO_BYTES = 5 * 1024 * 1024; // refuse files above 5 MB before processing them

// ---------- Personal information ----------
const validateProfile = ({ fullName, phone, email }, userId) => {
  const errors = {};
  if (!isNotEmpty(fullName)) errors.fullName = "error.required";

  if (!isNotEmpty(phone)) errors.phone = "error.required";
  else if (!isValidPhone(phone)) errors.phone = "error.phoneInvalid";

  if (!isNotEmpty(email)) errors.email = "error.required";
  else if (!isValidEmail(email)) errors.email = "error.emailInvalid";
  // The email may stay the same, but no OTHER user may already use it
  else if (getAll("users").some((u) => u.id !== userId && u.email === normalizeEmail(email))) {
    errors.email = "error.emailTaken";
  }
  return errors;
};

const updateProfile = (userId, formData) => {
  const errors = validateProfile(formData, userId);
  if (Object.keys(errors).length > 0) return { ok: false, errors };

  const { fullName, phone, email } = formData;
  const user = updateById("users", userId, {
    fullName: fullName.trim(),
    phone: phone.trim(),
    email: normalizeEmail(email),
  });
  return user ? { ok: true, user } : { ok: false, formError: "error.saveFailed" };
};

// ---------- Password ----------
const validatePasswordChange = ({ currentPassword, newPassword, confirmNewPassword }, user) => {
  const errors = {};
  if (!isNotEmpty(currentPassword)) errors.currentPassword = "error.required";
  else if (currentPassword !== user.password) errors.currentPassword = "error.currentPasswordWrong";

  if (!isNotEmpty(newPassword)) errors.newPassword = "error.required";
  else if (!isValidPassword(newPassword)) errors.newPassword = "error.passwordShort";
  else if (newPassword === currentPassword) errors.newPassword = "error.passwordSame";

  if (!isNotEmpty(confirmNewPassword)) errors.confirmNewPassword = "error.required";
  else if (confirmNewPassword !== newPassword) errors.confirmNewPassword = "error.passwordMismatch";
  return errors;
};

const changePassword = (userId, formData) => {
  const user = findById("users", userId); // read the stored user, do not trust a stale copy
  if (!user) return { ok: false, formError: "error.saveFailed" };

  const errors = validatePasswordChange(formData, user);
  if (Object.keys(errors).length > 0) return { ok: false, errors };

  return updateById("users", userId, { password: formData.newPassword })
    ? { ok: true }
    : { ok: false, formError: "error.saveFailed" };
};

// ---------- Photo ----------
// LocalStorage holds about 5 MB for the whole site, so a raw photo (often 3 MB) would not fit.
// We shrink it to a 200x200 JPEG (about 10-20 KB) with a <canvas> and store it as Base64 text.
const validatePhotoFile = (file) => {
  if (!file.type.startsWith("image/")) return "error.photoNotImage";
  if (file.size > MAX_PHOTO_BYTES) return "error.photoTooLarge";
  return null;
};

const readFileAsDataUrl = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });

const loadImage = (source) =>
  new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Image could not be loaded"));
    image.src = source;
  });

const resizeImage = async (file, size = PHOTO_SIZE) => {
  const image = await loadImage(await readFileAsDataUrl(file));
  const side = Math.min(image.width, image.height); // crop the largest centered square
  const sourceX = (image.width - side) / 2;
  const sourceY = (image.height - side) / 2;

  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  canvas.getContext("2d").drawImage(image, sourceX, sourceY, side, side, 0, 0, size, size);
  return canvas.toDataURL("image/jpeg", 0.8);
};

const handlePhotoChange = async (event, userId, avatar) => {
  const input = event.target;
  const file = input.files[0];
  clearFieldError("photo-input");
  if (!file) return;

  const errorKey = validatePhotoFile(file);
  if (errorKey) {
    showFieldError("photo-input", errorKey);
    input.value = "";
    return;
  }
  try {
    const dataUrl = await resizeImage(file);
    if (!updateById("users", userId, { photo: dataUrl })) {
      showFieldError("photo-input", "error.saveFailed");
      return;
    }
    avatar.src = dataUrl;
    showToast(t("toast.photoSaved"));
  } catch (error) {
    console.error("Pascoin: photo processing failed", error);
    showFieldError("photo-input", "error.photoFailed");
  } finally {
    input.value = ""; // allows choosing the same file again
  }
};

// ---------- Profile page ----------
const initProfilePage = (user) => {
  const profileForm = document.getElementById("profile-form");
  const passwordForm = document.getElementById("password-form");
  const avatar = document.getElementById("avatar-preview");

  // Fill the form with the stored values
  document.getElementById("fullName").value = user.fullName;
  document.getElementById("phone").value = user.phone;
  document.getElementById("email").value = user.email;
  if (user.photo) avatar.src = user.photo;

  setupForm(profileForm, (formData) => {
    const result = updateProfile(user.id, formData);
    if (!result.ok) return showFormErrors(profileForm, result);
    showToast(t("toast.profileSaved"));
  });

  setupForm(passwordForm, (formData) => {
    const result = changePassword(user.id, formData);
    if (!result.ok) return showFormErrors(passwordForm, result);
    passwordForm.reset();
    showToast(t("toast.passwordChanged"));
  });

  document.getElementById("photo-input").addEventListener("change", (event) =>
    handlePhotoChange(event, user.id, avatar));
};
